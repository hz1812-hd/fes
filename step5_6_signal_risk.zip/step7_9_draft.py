"""NHÁP cho Bước 7-9 (CHƯA thuộc Bước 5-6): giải thích, truy vết, kiểm tra phép tính (verify), what-if.
Tách riêng khỏi step5_6_signal_risk.py để Bước 5-6 chỉ xuất tín hiệu, risk score và mức ưu tiên."""
import numpy as np, pandas as pd
from step5_6_signal_risk import *

# ======================================================================= giải thích + truy vết
def fmt(v): return "n/a" if pd.isna(v) else (f"{v:,.0f}" if abs(v) >= 1000 else f"{v:.2f}")
NAMES = {"dso_days": "DSO", "inventory_days": "Inventory Days", "cfo_to_net_income": "CFO/Lợi nhuận ròng", "debt_to_assets_pct": "Nợ/Tổng tài sản (%)",
         "interest_coverage": "Interest Coverage", "gross_margin_pct": "Biên gộp (%)", "operating_margin_pct": "Biên hoạt động (%)", "current_ratio": "Current ratio",
         "free_cash_flow_vnd_mn": "FCF (triệu)"}
def explain(r, tag, s, parts):
    pp, tp, m, d = parts
    if tag == "WORKING_CAPITAL_PRESSURE":
        return f"{tag}: DSO {r.dso_days__chg1:+.1f} ngày và Inventory Days {r.inventory_days__chg1:+.1f} ngày so với năm trước, đi cùng dòng tiền yếu [điểm {s:.2f}]"
    if tag == "LIQUIDITY_STRESS":
        return f"{tag}: CFO = {fmt(r.cfo_vnd_mn)} triệu, FCF = {fmt(r.free_cash_flow_vnd_mn)} triệu (âm); biên CFO {r.cfo_margin_pct:.1f}% so với p25 ngành {fmt(r.cfo_margin_pct__p25)}% [điểm {s:.2f}]"
    if m is None or m not in r.index: return f"{tag}: điểm {s:.2f}"
    side = "p75" if d > 0 else "p25"; ref = r[f"{m}__{side}"]
    beyond = (r[m] > ref) if d > 0 else (r[m] < ref)
    cmp_ = ("vượt " if beyond else "chưa vượt ") + side + " ngành"
    ch = r.get(f"{m}__chg1", np.nan)
    txt = f"{NAMES.get(m, m)} = {fmt(r[m])}, {cmp_} {int(r.fiscal_year)} ({fmt(ref)}; trung vị {fmt(r[f'{m}__median'])})"
    if pd.notna(ch): txt += f"; so với năm trước {ch:+.2f}" + ("" if beyond else " (xu hướng xấu đi)")
    if tag == "RECEIVABLES_RISK": txt += f"; phải thu tăng {r.ar_growth_pct:.1f}% so với doanh thu {r.revenue_growth_pct:.1f}%"
    if tag == "INVENTORY_RISK": txt += f"; tồn kho tăng {r.inv_growth_pct:.1f}% so với doanh thu {r.revenue_growth_pct:.1f}%"
    if tag.startswith("CFO") or tag == "PROFIT_CASH_DIVERGENCE": txt += f"; CFO = {fmt(r.cfo_vnd_mn)} triệu, biên ròng {r.net_margin_pct:.1f}%"
    return f"{tag}: {txt} [điểm {s:.2f}]"
def evidence(r, metric):
    fields = EVID.get(metric, []) if metric else []
    return [f"{SRC.get(f, 'financial_notes.csv')}:{r.company_id}:{int(r.fiscal_year)}:{f}" for f in fields]

# ======================================================================= VERIFY (Gold): tính lại từ số liệu gốc, so với chỉ tiêu Bước 2
def verify(df, tol=1e-6):
    chk = {"gross_margin_pct": (df.revenue_vnd_mn - df.cost_of_goods_sold_vnd_mn) / df.revenue_vnd_mn * 100,
           "operating_margin_pct": df.operating_profit_vnd_mn / df.revenue_vnd_mn * 100,
           "net_margin_pct": df.net_income_vnd_mn / df.revenue_vnd_mn * 100,
           "current_ratio": df.total_current_assets_vnd_mn / df.total_current_liabilities_vnd_mn,
           "debt_to_equity": df.total_debt_vnd_mn / df.total_equity_vnd_mn,
           "debt_to_assets_pct": df.total_debt_vnd_mn / df.total_assets_vnd_mn * 100,
           "cfo_to_net_income": df.cfo_vnd_mn / df.net_income_vnd_mn,
           "free_cash_flow_vnd_mn": df.cfo_vnd_mn + df.capital_expenditure_vnd_mn,
           "interest_coverage": df.operating_profit_vnd_mn / df.interest_expense_vnd_mn}
    bad = pd.DataFrame({m: ((v - df[m]).abs() > tol * np.maximum(1, df[m].abs())) & df[m].notna() for m, v in chk.items()})
    # kiểm tra đẳng thức kế toán
    bad["balance_sheet"] = (df.total_assets_vnd_mn - df.total_liabilities_and_equity_vnd_mn).abs() > 1
    return bad.any(axis=1).map({True: "FAIL", False: "PASS"}), bad


# ======================================================================= what-if
def what_if(df, company, year, changes, P):
    """changes: {cột: hệ số nhân}, ví dụ {'dso_days': .8, 'inventory_days': .8}. Tính lại điểm rủi ro của dòng đó."""
    d2 = df.copy(); m = (d2.company_id == company) & (d2.fiscal_year == year)
    for c, f in changes.items(): d2.loc[m, c] = d2.loc[m, c] * f
    g = d2.groupby("company_id")
    for mm in BMETRICS:
        if mm in changes: d2[f"{mm}__chg1"] = g[mm].diff(); d2[f"{mm}__chg2"] = g[mm].diff(2)
    O, *_ = run(d2, P); return O[(O.company_id == company) & (O.fiscal_year == year)].iloc[0]

